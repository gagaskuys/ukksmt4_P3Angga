<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('aspirasis', function (Blueprint $table) {
    $table->id(); 
    
    $table->foreignId('siswa_id')->constrained('siswas')->onDelete('cascade');
    
    // Perbaikan di sini:
    $table->foreignId('kategori_id')->references('id_kategori')->on('kategoris')->onDelete('cascade');
    
    $table->foreignId('ruangan_id')->constrained('ruangans')->onDelete('cascade');

    $table->text('deskripsi_laporan');
    $table->string('foto', 255)->nullable();
    $table->enum('status', ['menunggu', 'proses', 'selesai'])->default('menunggu');
});

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('aspirasis');
    }
};
