<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kelas extends Model
{
    protected $table = 'kelas';

    protected $fillable = [
        'nama_kelas',
    ];

    public function aspirasi()
    {
        return $this->hasMany(Aspirasi::class, 'kelas_id');
    }
    public $timestamps = true; // Tetap aktifkan timestamps agar bisa diisi manual
}
