<?php

namespace App\Http\Controllers;

use App\Models\Aspirasi;
use App\Models\Kategori;
use App\Models\Ruangan;
use Illuminate\Http\Request;

class AspirasiController extends Controller
{
    public function monitoring(Request $request)
    {
        $query = Aspirasi::with(['siswa', 'guru', 'kategori', 'ruangan'])->orderBy('created_at', 'DESC');

        if (request()->routeIs('guru.laporan.selesai')) {
            $query->where('status', 'selesai');
        }

        $aspirasis = $query->paginate(10);
        return view('aspirasi.monitoring', compact('aspirasis'));
    }

    public function create()
    {
        $kategoris = Kategori::all();
        $ruangans = Ruangan::all();
        return view('siswa.create', compact('kategoris', 'ruangans'));
    }


    public function store(Request $request)
    {
        $request->validate([
            'kategori_id'       => 'required',
            'ruangan_id'        => 'required',
            'deskripsi_laporan' => 'required',
            'foto'              => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $dataInput = [
            'kategori_id'       => $request->kategori_id,
            'ruangan_id'        => $request->ruangan_id,
            'deskripsi_laporan' => $request->deskripsi_laporan,
            'status'            => 'menunggu',
            'feedback_admin'    => null,
        ];

        $user = auth()->user();

        if ($user->role === 'siswa') { 
            $dataInput['siswa_id'] = $user->siswa->id;
            $dataInput['guru_id']  = null;
        } 
        elseif ($user->role === 'guru') { 
            $dataInput['guru_id']  = $user->guru->id; 
            $dataInput['siswa_id'] = null;
        }
        else {
            $dataInput['siswa_id'] = null;
            $dataInput['guru_id']  = null;
        }

        // ✅ SIMPAN FOTO KE PUBLIC/IMG/
        if ($request->hasFile('foto')) {
            $file = $request->file('foto');
            $namaFile = time() . '_' . $file->getClientOriginalName();
            
            // Simpan ke public/img/
            $file->move(public_path('img'), $namaFile);
            
            // Simpan hanya nama file ke database
            $dataInput['foto'] = $namaFile; 
        }
        
        Aspirasi::create($dataInput);
        return redirect()->route('aspirasi.history')->with('success', 'Laporan aspirasi berhasil dikirim!');
    }

    public function history()
    {
        $user = auth()->user();

        // ✅ Filter data sesuai akun yang login
        $aspirasis = Aspirasi::with(['kategori', 'ruangan', 'siswa', 'guru'])
                        ->when($user->role === 'siswa', function($q) use ($user){
                            return $q->where('siswa_id', $user->siswa->id);
                        })
                        ->when($user->role === 'guru', function($q) use ($user){
                            return $q->where('guru_id', $user->guru->id);
                        })
                        ->orderBy('created_at', 'DESC')
                        ->paginate(10);

        return view('aspirasi.history', compact('aspirasis'));
    }

    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'status'         => 'required|in:menunggu,proses,selesai',
            'feedback_admin' => 'nullable|string',
        ]);

        $aspirasi = Aspirasi::findOrFail($id);
        $aspirasi->update([
            'status'         => $request->status,
            'feedback_admin' => $request->feedback_admin,
        ]);

        return redirect()->back()->with('success', 'Status dan tanggapan berhasil diperbarui!');
    }

    public function show($id)
    {
        $aspirasi = Aspirasi::with(['siswa', 'guru', 'kategori', 'ruangan'])->findOrFail($id);
        return view('aspirasi.detail', compact('aspirasi'));
    }
    public function hapus($id)
    {
        $aspirasi = Aspirasi::findOrFail($id);

        // HAPUS FILE FOTO DARI PUBLIC/IMG/
        if($aspirasi->foto) {
            $pathFoto = public_path('img/' . $aspirasi->foto);
            if(file_exists($pathFoto)){
                unlink($pathFoto);
            }
        }

        $aspirasi->delete();
        return redirect()->route('aspirasi.monitoring')->with('success', '✅ Berhasil dihapus!');
    }
}