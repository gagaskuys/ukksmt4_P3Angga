
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="title-wrapper pt-30">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="title mb-30">
                    <h2>📜 Sejarah Aspirasi Saya</h2>
                </div>
            </div>
        </div>
    </div>

    
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
    </div>
    <?php endif; ?>

    <?php $__currentLoopData = $aspirasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aspirasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card-style mb-30">
        <div class="d-flex justify-content-between align-items-start mb-2">
            <h5 class="text-primary fw-bold mb-0">Aspirasi #<?php echo e($loop->iteration); ?></h5>
            
            
            <?php if($aspirasi->status == 'menunggu'): ?>
                <span class="badge rounded-pill bg-warning text-dark px-3 py-2">⏳ MENUNGGU</span>
            <?php elseif($aspirasi->status == 'proses'): ?>
                <span class="badge rounded-pill bg-info text-white px-3 py-2">🔄 DIPROSES</span>
            <?php else: ?>
                <span class="badge rounded-pill bg-success text-white px-3 py-2">✅ SELESAI</span>
            <?php endif; ?>
        </div>

        <hr>

        <div class="row">
            
            <div class="col-md-8">
                <table class="table table-borderless table-sm">
                    <tr>
                        <td width="120" class="text-muted">Kategori</td>
                        <td>: <strong><?php echo e($aspirasi->kategori->nama_kategori ?? '-'); ?></strong></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Lokasi / Ruangan</td>
                        <td>: <strong><?php echo e($aspirasi->ruangan->nama_ruangan ?? '-'); ?></strong></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Waktu Kirim</td>
                        <td>: <?php echo e($aspirasi->created_at->format('d/m/Y | H:i')); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Laporan</td>
                        <td>: <?php echo e($aspirasi->deskripsi_laporan); ?></td>
                    </tr>
                </table>
            </div>

            
<div class="col-md-4 text-center">
    <?php if($aspirasi->foto): ?>
        <?php
            $fullPath = public_path('img/' . $aspirasi->foto);
            $fileExists = file_exists($fullPath);
        ?>
        
        <?php if($fileExists): ?>
            <p class="text-muted mb-1">📸 Bukti Foto</p>
            <a href="<?php echo e(url('img/' . $aspirasi->foto)); ?>" target="_blank">
                <img src="<?php echo e(url('img/' . $aspirasi->foto)); ?>" 
                     width="150" 
                     height="120" 
                     class="img-thumbnail rounded shadow-sm" 
                     style="object-fit: cover; cursor: pointer;" 
                     alt="Bukti Foto">
            </a>
        <?php else: ?>
            <div class="alert alert-warning py-1 px-2 small">
                ⚠️ File tidak ditemukan: <?php echo e($aspirasi->foto); ?>

            </div>
        <?php endif; ?>
    <?php else: ?>
        <span class="text-muted fst-italic">📷 Tidak ada foto</span>
    <?php endif; ?>
</div>
        </div> 

        
        <div class="mt-4 p-3 rounded border-start border-4 border-primary bg-light">
            <h6 class="mb-2 text-primary">📩 Tanggapan / Balasan Admin:</h6>
            
            <?php if($aspirasi->feedback_admin): ?>
                <p class="mb-0 fst-italic text-dark">
                    <?php echo e($aspirasi->feedback_admin); ?>

                </p>
            <?php else: ?>
                <p class="mb-0 text-muted fst-italic">
                    ⏳ Belum ada tanggapan dari admin. Mohon ditunggu.
                </p>
            <?php endif; ?>
        </div>

    </div> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php if($aspirasis->isEmpty()): ?>
    <div class="card-style mb-30 text-center py-5">
        <h4 class="text-muted">📭 Anda belum mengirimkan aspirasi apapun.</h4>
        <a href="<?php echo e(route('siswa.create')); ?>" class="btn btn-primary mt-3">➕ Buat Aspirasi Baru</a>
    </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Project_Ralavel\resources\views/aspirasi/history.blade.php ENDPATH**/ ?>