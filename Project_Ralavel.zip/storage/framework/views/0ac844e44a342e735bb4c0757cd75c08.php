

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="title-wrapper pt-30">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="title mb-30">
                    <h2>Kirim Aspirasi Baru</h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Tampilkan Pesan Galat Jika Ada -->
    <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
    </div>
    <?php endif; ?>

    <div class="card-style mb-30">
        <form action="<?php echo e(route('aspirasi.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
           <!-- Pilihan Kategori Kerusakan (Sudah Seragam Menggunakan $kat) -->
<div class="select-style-1">
    <label>Kategori Kerusakan</label>
    <div class="select-position">
        <select name="kategori_id" required>
            <option value="">-- Pilih Kategori --</option>
            <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- ✅ UBAH $kat->id MENJADI $kat->id_kategori -->
                <option value="<?php echo e($kat->id_kategori); ?>" <?php echo e(old('kategori_id') == $kat->id_kategori ? 'selected' : ''); ?>>
                    <?php echo e($kat->nama_kategori); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<!-- Pilihan Lokasi / Ruangan -->
<div class="select-style-1">
    <label>Lokasi / Ruangan</label>
    <div class="select-position">
        <select name="ruangan_id" required>
            <option value="">-- Pilih Ruangan --</option>
            <?php $__currentLoopData = $ruangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- ✅ Ini sudah BENAR, karena di tabel ruangan kuncinya emang 'id' -->
                <option value="<?php echo e($r->id); ?>" <?php echo e(old('ruangan_id') == $r->id ? 'selected' : ''); ?>>
                    <?php echo e($r->nama_ruangan); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<!-- Deskripsi Laporan -->
<div class="input-style-1">
    <label>Detail Kerusakan / Aspirasi</label>
    <textarea name="deskripsi_laporan" rows="5" placeholder="Jelaskan secara rinci apa yang rusak atau apa yang menjadi usulanmu..." required><?php echo e(old('deskripsi_laporan')); ?></textarea>
</div>

            <!-- Unggah Foto Bukti -->
            <div class="input-style-1">
                <label>Foto Bukti</label>
                <input type="file" name="foto" accept="image/*" />
                <small class="text-muted">Format yang diizinkan: JPG, PNG, JPEG. Ukuran maksimal: 2MB.</small>
            </div>

            <div class="mt-4">
                <button type="submit" class="main-btn primary-btn btn-hover">Kirim Aspirasi</button>
                <a href="<?php echo e(route('aspirasi.history')); ?>" class="main-btn secondary-btn btn-hover ms-2">Batal</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Project_Ralavel\resources\views/siswa/create.blade.php ENDPATH**/ ?>