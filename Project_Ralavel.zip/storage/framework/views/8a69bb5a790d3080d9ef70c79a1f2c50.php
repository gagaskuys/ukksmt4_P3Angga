

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Judul Halaman -->
    <div class="title-wrapper pt-30">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="title mb-30">
                    <h2>Dashboard Admin (Rekap & Statistik)</h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Kotak Statistik (Cards) -->
    <div class="row">
        <!-- Card Total Siswa -->
        <div class="col-xl-3 col-lg-4 col-sm-6">
            <div class="icon-card mb-30">
                <div class="icon purple">
                    <i class="lni lni-users"></i>
                </div>
                <div class="content">
                    <h6 class="mb-10">Total Siswa</h6>
                    <h3 class="text-bold mb-10"><?php echo e($totalSiswa); ?></h3>
                </div>
            </div>
        </div>

        <!-- Card Total Guru -->
        <div class="col-xl-3 col-lg-4 col-sm-6">
            <div class="icon-card mb-30">
                <div class="icon success">
                    <i class="lni lni-user"></i>
                </div>
                <div class="content">
                    <h6 class="mb-10">Total Guru</h6>
                    <h3 class="text-bold mb-10"><?php echo e($totalGuru); ?></h3>
                </div>
            </div>
        </div>

        <!-- Card Total Aspirasi -->
        <div class="col-xl-3 col-lg-4 col-sm-6">
            <div class="icon-card mb-30">
                <div class="icon primary">
                    <i class="lni lni-archive"></i>
                </div>
                <div class="content">
                    <h6 class="mb-10">Total Aspirasi</h6>
                    <h3 class="text-bold mb-10"><?php echo e($totalAspirasi); ?></h3>
                </div>
            </div>
        </div>

        <!-- Card Total Kepala Sekolah -->
        <div class="col-xl-3 col-lg-4 col-sm-6">
            <div class="icon-card mb-30">
                <div class="icon warning">
                    <i class="lni lni-user"></i>
                </div>
                <div class="content">
                    <h6 class="mb-10">Total Kepala Sekolah</h6>
                    <h3 class="text-bold mb-10"><?php echo e($totalKepsek); ?></h3>
                </div>
            </div>
        </div>

        <!-- Card Total Petugas -->
        <div class="col-xl-3 col-lg-4 col-sm-6">
            <div class="icon-card mb-30">
                <div class="icon success">
                    <i class="lni lni-user"></i>
                </div>
                <div class="content">
                    <h6 class="mb-10">Total Petugas</h6>
                    <h3 class="text-bold mb-10"><?php echo e($totalPetugas); ?></h3>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Project_Ralavel\resources\views/admin/dashboard/admin.blade.php ENDPATH**/ ?>