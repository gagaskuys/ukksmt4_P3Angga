
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="title-wrapper pt-30">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="title mb-30">
                    <h2>📊 Monitoring Aspirasi Siswa</h2>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-lg-4 col-md-6 col-sm-6">
            <div class="card-style mb-30 bg-warning text-white">
                <div class="card-body">
                    <h5 class="card-title text-white">⚡ MENUNGGU</h5>
                    <p class="card-text display-6">
                        <?php echo e($aspirasis->where('status', 'menunggu')->count()); ?> Laporan
                    </p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6">
            <div class="card-style mb-30 bg-info text-white">
                <div class="card-body">
                    <h5 class="card-title text-white">🔄 DIPROSES</h5>
                    <p class="card-text display-6">
                        <?php echo e($aspirasis->where('status', 'proses')->count()); ?> Laporan
                    </p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-6">
            <div class="card-style mb-30 bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title text-white">✅ SELESAI</h5>
                    <p class="card-text display-6">
                        <?php echo e($aspirasis->where('status', 'selesai')->count()); ?> Laporan
                    </p>
                </div>
            </div>
        </div>
    </div>

    
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
    </div>
    <?php endif; ?>

    <div class="card-style mb-30">
        <div class="table-wrapper table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th width="12%"><h6>Pelapor</h6></th>
                        <th width="10%"><h6>Kategori</h6></th>
                        <th width="10%"><h6>Ruangan</h6></th>
                        <th width="15%"><h6>Deskripsi</h6></th>
                        <th width="8%"><h6>Foto</h6></th>
                        <th width="10%"><h6>Status</h6></th>
                        <th width="20%"><h6>Tanggapan / Feedback</h6></th>
                        <th width="15%"><h6>Aksi</h6></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $aspirasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aspirasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td>
                        <?php if($aspirasi->siswa_id != null): ?>
                            <p class="text-sm fw-bold mb-0">👨‍🎓 <?php echo e($aspirasi->siswa->name ?? 'Siswa Tidak Diketahui'); ?></p>
                        <?php elseif($aspirasi->guru_id != null): ?>
                            <p class="text-sm fw-bold mb-0">👨‍🏫 <?php echo e($aspirasi->guru->name ?? 'Guru / Staf'); ?></p>
                        <?php endif; ?>
                        <small class="text-muted"><?php echo e($aspirasi->created_at->format('d/m/Y H:i')); ?></small>
                        </td>
                        
                        
                        <td>
                            <span class="text-sm"><?php echo e($aspirasi->kategori->nama_kategori ?? '-'); ?></span>
                        </td>

                        
                        <td>
                            <span class="text-sm"><?php echo e($aspirasi->ruangan->nama_ruangan ?? '-'); ?></span>
                        </td>

                        
                        <td>
                            <p class="text-sm text-truncate-2" style="max-width: 180px;" title="<?php echo e($aspirasi->deskripsi_laporan); ?>">
                                <?php echo e($aspirasi->deskripsi_laporan); ?>

                            </p>
                        </td>

                        
                        <td class="text-center">
                            <?php if($aspirasi->foto): ?>
                                <?php
                                    // Ambil cuma nama file, buang jalur lain kalau ada
                                    $namaMurni = basename($aspirasi->foto);
                                ?>
                                
                                
                                <a href="<?php echo e(url('img/'.$namaMurni)); ?>" target="_blank" title="Klik lihat ukuran asli">
                                    <img src="<?php echo e(url('img/'.$namaMurni)); ?>" 
                                         width="60" 
                                         height="60" 
                                         class="img-thumbnail rounded" 
                                         style="object-fit: cover; border:2px solid #28a745;" 
                                         alt="Bukti Foto">
                                </a>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        

                        
                        <td class="text-center">
                            <?php if($aspirasi->status == 'menunggu'): ?>
                                <span class="badge rounded-pill bg-warning text-dark px-3 py-2">Menunggu</span>
                            <?php elseif($aspirasi->status == 'proses'): ?>
                                <span class="badge rounded-pill bg-info text-white px-3 py-2">Proses</span>
                            <?php else: ?>
                                <span class="badge rounded-pill bg-success text-white px-3 py-2">Selesai</span>
                            <?php endif; ?>
                        </td>

                        
                        <td>
                            <form action="<?php echo e(route('aspirasi.updateStatus', $aspirasi->id)); ?>" method="POST" id="formUbah<?php echo e($aspirasi->id); ?>">
                                <?php echo csrf_field(); ?>
                                <textarea name="feedback_admin" 
                                          class="form-control form-control-sm" 
                                          rows="3" 
                                          placeholder="Tulis balasan di sini..."
                                          style="font-size: 0.85rem;"><?php echo e($aspirasi->feedback_admin); ?></textarea>
                        </td>

                        
                        <td>
                                <select name="status" class="form-select form-select-sm mb-2" style="font-size: 0.85rem;">
                                    <option value="menunggu" <?php echo e($aspirasi->status == 'menunggu' ? 'selected' : ''); ?>>Menunggu</option>
                                    <option value="proses" <?php echo e($aspirasi->status == 'proses' ? 'selected' : ''); ?>>Diproses</option>
                                    <option value="selesai" <?php echo e($aspirasi->status == 'selesai' ? 'selected' : ''); ?>>Selesai</option>
                                </select>
                                <button type="submit" form="formUbah<?php echo e($aspirasi->id); ?>" class="btn btn-sm btn-primary w-100 mb-1">
                                    💾 Simpan
                                </button>
                            </form> 

                            
                            <form action="<?php echo e(route('aspirasi.hapus', $aspirasi->id)); ?>" method="POST" 
                                  onsubmit="return confirm('⚠️ PERINGATAN: Data akan dihapus permanen!\nYakin mau hapus laporan ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger w-100">
                                    🗑️ Hapus
                                </button>
                            </form>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            
            <div class="mt-3 d-flex justify-content-center">
                <?php echo e($aspirasis->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Project_Ralavel\resources\views/aspirasi/monitoring.blade.php ENDPATH**/ ?>