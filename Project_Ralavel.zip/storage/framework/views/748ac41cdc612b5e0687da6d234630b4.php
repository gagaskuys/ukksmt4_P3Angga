
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="title-wrapper pt-30">
        <h2>Tambah Ruangan Baru</h2>
    </div>

    <div class="card-style mb-30">
        <form action="<?php echo e(route('admin.ruangan.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="input-style-1">
                <label>Nama Ruangan</label>
                <input type="text" name="nama_ruangan" placeholder="Masukkan nama ruangan" required>
            </div>
                <div class="text-end">
                    <a href="<?php echo e(route('admin.ruangan.index')); ?>" class="main-btn danger-btn-outline btn-hover">Batal</a>
            <button type="submit" class="main-btn success-btn rounded-md btn-hover">Simpan</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Project_Ralavel\resources\views/admin/ruangan/create.blade.php ENDPATH**/ ?>