
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Tambah Kategori Baru</h1>
    <form action="<?php echo e(route('admin.kategori.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="input-style-1">
            <label>Nama Kategori</label>
            <input type="text" name="nama_kategori" placeholder="Masukkan nama kategori" required>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Project_Ralavel\resources\views/admin/kategori/create.blade.php ENDPATH**/ ?>