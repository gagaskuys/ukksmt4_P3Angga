@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="title-wrapper pt-30">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="title mb-30">
                    <h2>Kelola Data Kelas</h2>
                </div>
            </div>
            <div class="col-md-6 text-end mb-30">
                <a href="{{ route('admin.kelas.create') }}" class="main-btn primary-btn btn-hover">Tambah Kelas Baru</a>
            </div>
        </div>
    </div>

    @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
    </div>
    @endif

    <div class="card-style mb-30">
        <div class="table-wrapper table-responsive">
            <!-- Menambahkan class table-bordered dan table-striped agar tampilan tabel tegas -->
            <table class="table table-bordered table-striped align-middle m-0">
                <thead>
                    <tr class="bg-light">
                        <th class="px-3 py-3" style="width: 80px;"><h6>No</h6></th>
                        <th class="px-3 py-3"><h6>Nama Kelas</h6></th>
                        <th class="px-3 py-3 text-center" style="width: 200px;"><h6>Aksi</h6></th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($kelass as $key => $kelas)
                    <tr>
                        <td class="px-3 py-3">{{ $key + 1 }}</td>
                        <td class="px-3 py-3 fw-bold text-dark">{{ $kelas->nama_kelas }}</td>
                        <td class="px-3 py-3 text-center">
                            <div class="action justify-content-center">
                                <!-- Mengubah tombol menjadi gaya minimalis ikon khas PlainAdmin -->
                                <a href="{{ route('admin.kelas.edit', $kelas->id) }}" class="text-primary me-3 text-decoration-none">
                                    <i class="lni lni-pencil"></i> Ubah
                                </a>
                                <form action="{{ route('admin.kelas.destroy', $kelas->id) }}" method="POST" class="d-inline m-0">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-danger border-0 bg-transparent p-0" onclick="return confirm('Apakah Anda yakin ingin menghapus kelas ini?')">
                                        <i class="lni lni-trash-can"></i> Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <!-- Mengubah colspan menjadi 3 agar pas di tengah-tengah tabel -->
                        <td colspan="3" class="text-center text-muted py-4">Tidak ada data kelas.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
